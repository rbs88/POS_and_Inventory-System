﻿namespace UI
{
    partial class frmSchedulecs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSchedulecs));
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAcademicYear = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cboStrand = new System.Windows.Forms.ComboBox();
            this.cboGradeLevel = new System.Windows.Forms.ComboBox();
            this.cboSection = new System.Windows.Forms.ComboBox();
            this.txtAdviserID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cboSubjectCode = new System.Windows.Forms.ComboBox();
            this.cboAdviserName = new System.Windows.Forms.ComboBox();
            this.txtDescriptiveTitle = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtUnits = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.chkM = new System.Windows.Forms.CheckBox();
            this.chkF = new System.Windows.Forms.CheckBox();
            this.chkTH = new System.Windows.Forms.CheckBox();
            this.chkW = new System.Windows.Forms.CheckBox();
            this.chkT = new System.Windows.Forms.CheckBox();
            this.chkS = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.maskFrom = new System.Windows.Forms.MaskedTextBox();
            this.maskTo = new System.Windows.Forms.MaskedTextBox();
            this.txtTeacherID = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cboSubjectTeacher = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtYearTerm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboRoom = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(1170, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "[X]";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1199, 26);
            this.panel1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "SCHEDULE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(31, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "AY CODE";
            // 
            // txtAcademicYear
            // 
            this.txtAcademicYear.Enabled = false;
            this.txtAcademicYear.Location = new System.Drawing.Point(129, 55);
            this.txtAcademicYear.Name = "txtAcademicYear";
            this.txtAcademicYear.Size = new System.Drawing.Size(259, 23);
            this.txtAcademicYear.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(30, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "STRAND";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(30, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "GRADE LEVEL";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(30, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "SECTION";
            // 
            // cboStrand
            // 
            this.cboStrand.FormattingEnabled = true;
            this.cboStrand.Location = new System.Drawing.Point(129, 109);
            this.cboStrand.Name = "cboStrand";
            this.cboStrand.Size = new System.Drawing.Size(259, 23);
            this.cboStrand.TabIndex = 21;
            this.cboStrand.SelectedIndexChanged += new System.EventHandler(this.cboStrand_SelectedIndexChanged);
            this.cboStrand.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboStrand_KeyPress);
            // 
            // cboGradeLevel
            // 
            this.cboGradeLevel.FormattingEnabled = true;
            this.cboGradeLevel.Items.AddRange(new object[] {
            "PREPARATORY",
            "KINDER 1",
            "KINDER 2",
            "GRADE 1",
            "GRADE 2",
            "GRADE 3",
            "GRADE 4",
            "GRADE 5",
            "GRADE 6",
            "GRADE 7",
            "GRADE 8",
            "GRADE 9",
            "GRADE 10",
            "GRADE 11",
            "GRADE 12"});
            this.cboGradeLevel.Location = new System.Drawing.Point(129, 138);
            this.cboGradeLevel.Name = "cboGradeLevel";
            this.cboGradeLevel.Size = new System.Drawing.Size(259, 23);
            this.cboGradeLevel.TabIndex = 22;
            this.cboGradeLevel.SelectedIndexChanged += new System.EventHandler(this.cboGradeLevel_SelectedIndexChanged);
            // 
            // cboSection
            // 
            this.cboSection.FormattingEnabled = true;
            this.cboSection.Location = new System.Drawing.Point(129, 167);
            this.cboSection.Name = "cboSection";
            this.cboSection.Size = new System.Drawing.Size(259, 23);
            this.cboSection.TabIndex = 23;
            // 
            // txtAdviserID
            // 
            this.txtAdviserID.Enabled = false;
            this.txtAdviserID.Location = new System.Drawing.Point(530, 56);
            this.txtAdviserID.Name = "txtAdviserID";
            this.txtAdviserID.Size = new System.Drawing.Size(259, 23);
            this.txtAdviserID.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(426, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 15);
            this.label9.TabIndex = 24;
            this.label9.Text = "ADVISER ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(426, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 15);
            this.label10.TabIndex = 26;
            this.label10.Text = "ADVISER NAME";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(426, 124);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 15);
            this.label11.TabIndex = 27;
            this.label11.Text = "SUBJECT CODE";
            // 
            // cboSubjectCode
            // 
            this.cboSubjectCode.FormattingEnabled = true;
            this.cboSubjectCode.Location = new System.Drawing.Point(530, 116);
            this.cboSubjectCode.Name = "cboSubjectCode";
            this.cboSubjectCode.Size = new System.Drawing.Size(259, 23);
            this.cboSubjectCode.TabIndex = 29;
            this.cboSubjectCode.SelectedIndexChanged += new System.EventHandler(this.cboSubjectCode_SelectedIndexChanged);
            // 
            // cboAdviserName
            // 
            this.cboAdviserName.FormattingEnabled = true;
            this.cboAdviserName.Location = new System.Drawing.Point(530, 87);
            this.cboAdviserName.Name = "cboAdviserName";
            this.cboAdviserName.Size = new System.Drawing.Size(259, 23);
            this.cboAdviserName.TabIndex = 28;
            this.cboAdviserName.SelectedIndexChanged += new System.EventHandler(this.cboAdviserName_SelectedIndexChanged);
            // 
            // txtDescriptiveTitle
            // 
            this.txtDescriptiveTitle.Location = new System.Drawing.Point(530, 146);
            this.txtDescriptiveTitle.Multiline = true;
            this.txtDescriptiveTitle.Name = "txtDescriptiveTitle";
            this.txtDescriptiveTitle.Size = new System.Drawing.Size(259, 49);
            this.txtDescriptiveTitle.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(426, 154);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 15);
            this.label12.TabIndex = 30;
            this.label12.Text = "DESCRIPTIVE TITLE";
            // 
            // txtUnits
            // 
            this.txtUnits.Location = new System.Drawing.Point(530, 202);
            this.txtUnits.Name = "txtUnits";
            this.txtUnits.Size = new System.Drawing.Size(259, 23);
            this.txtUnits.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(426, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 15);
            this.label13.TabIndex = 32;
            this.label13.Text = "UNIT(S)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(841, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 15);
            this.label14.TabIndex = 34;
            this.label14.Text = "DAYS";
            // 
            // chkM
            // 
            this.chkM.AutoSize = true;
            this.chkM.ForeColor = System.Drawing.Color.Black;
            this.chkM.Location = new System.Drawing.Point(891, 64);
            this.chkM.Name = "chkM";
            this.chkM.Size = new System.Drawing.Size(37, 19);
            this.chkM.TabIndex = 35;
            this.chkM.Text = "M";
            this.chkM.UseVisualStyleBackColor = true;
            // 
            // chkF
            // 
            this.chkF.AutoSize = true;
            this.chkF.ForeColor = System.Drawing.Color.Black;
            this.chkF.Location = new System.Drawing.Point(944, 95);
            this.chkF.Name = "chkF";
            this.chkF.Size = new System.Drawing.Size(32, 19);
            this.chkF.TabIndex = 36;
            this.chkF.Text = "F";
            this.chkF.UseVisualStyleBackColor = true;
            // 
            // chkTH
            // 
            this.chkTH.AutoSize = true;
            this.chkTH.ForeColor = System.Drawing.Color.Black;
            this.chkTH.Location = new System.Drawing.Point(891, 95);
            this.chkTH.Name = "chkTH";
            this.chkTH.Size = new System.Drawing.Size(40, 19);
            this.chkTH.TabIndex = 37;
            this.chkTH.Text = "TH";
            this.chkTH.UseVisualStyleBackColor = true;
            // 
            // chkW
            // 
            this.chkW.AutoSize = true;
            this.chkW.ForeColor = System.Drawing.Color.Black;
            this.chkW.Location = new System.Drawing.Point(997, 64);
            this.chkW.Name = "chkW";
            this.chkW.Size = new System.Drawing.Size(38, 19);
            this.chkW.TabIndex = 38;
            this.chkW.Text = "W";
            this.chkW.UseVisualStyleBackColor = true;
            // 
            // chkT
            // 
            this.chkT.AutoSize = true;
            this.chkT.ForeColor = System.Drawing.Color.Black;
            this.chkT.Location = new System.Drawing.Point(944, 64);
            this.chkT.Name = "chkT";
            this.chkT.Size = new System.Drawing.Size(32, 19);
            this.chkT.TabIndex = 39;
            this.chkT.Text = "T";
            this.chkT.UseVisualStyleBackColor = true;
            // 
            // chkS
            // 
            this.chkS.AutoSize = true;
            this.chkS.ForeColor = System.Drawing.Color.Black;
            this.chkS.Location = new System.Drawing.Point(997, 95);
            this.chkS.Name = "chkS";
            this.chkS.Size = new System.Drawing.Size(32, 19);
            this.chkS.TabIndex = 40;
            this.chkS.Text = "S";
            this.chkS.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(839, 144);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 15);
            this.label15.TabIndex = 41;
            this.label15.Text = "TIME[FROM-TO]";
            // 
            // maskFrom
            // 
            this.maskFrom.Location = new System.Drawing.Point(942, 138);
            this.maskFrom.Mask = "##:##";
            this.maskFrom.Name = "maskFrom";
            this.maskFrom.Size = new System.Drawing.Size(62, 23);
            this.maskFrom.TabIndex = 42;
            // 
            // maskTo
            // 
            this.maskTo.Location = new System.Drawing.Point(1010, 138);
            this.maskTo.Mask = "##:##";
            this.maskTo.Name = "maskTo";
            this.maskTo.Size = new System.Drawing.Size(62, 23);
            this.maskTo.TabIndex = 43;
            // 
            // txtTeacherID
            // 
            this.txtTeacherID.Enabled = false;
            this.txtTeacherID.Location = new System.Drawing.Point(942, 173);
            this.txtTeacherID.Name = "txtTeacherID";
            this.txtTeacherID.Size = new System.Drawing.Size(244, 23);
            this.txtTeacherID.TabIndex = 45;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(840, 181);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 15);
            this.label16.TabIndex = 44;
            this.label16.Text = "TEACHER ID";
            // 
            // cboSubjectTeacher
            // 
            this.cboSubjectTeacher.FormattingEnabled = true;
            this.cboSubjectTeacher.Location = new System.Drawing.Point(943, 202);
            this.cboSubjectTeacher.Name = "cboSubjectTeacher";
            this.cboSubjectTeacher.Size = new System.Drawing.Size(243, 23);
            this.cboSubjectTeacher.TabIndex = 47;
            this.cboSubjectTeacher.SelectedIndexChanged += new System.EventHandler(this.cboSubjectTeacher_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(839, 210);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 15);
            this.label17.TabIndex = 46;
            this.label17.Text = "SUBJECT TEACHER";
            // 
            // btnCancel
            // 
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(291, 234);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 49;
            this.btnCancel.Text = "&CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(129, 234);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 48;
            this.btnSave.Text = "&SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(210, 234);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 51;
            this.button2.Text = "&UPDATE";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeight = 25;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column12,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(4, 276);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 30;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1191, 297);
            this.dataGridView1.TabIndex = 52;
            // 
            // txtYearTerm
            // 
            this.txtYearTerm.Enabled = false;
            this.txtYearTerm.Location = new System.Drawing.Point(129, 82);
            this.txtYearTerm.Name = "txtYearTerm";
            this.txtYearTerm.Size = new System.Drawing.Size(259, 23);
            this.txtYearTerm.TabIndex = 54;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(30, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 53;
            this.label4.Text = "YEAR/TERM";
            // 
            // cboRoom
            // 
            this.cboRoom.FormattingEnabled = true;
            this.cboRoom.Location = new System.Drawing.Point(128, 197);
            this.cboRoom.Name = "cboRoom";
            this.cboRoom.Size = new System.Drawing.Size(259, 23);
            this.cboRoom.TabIndex = 56;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(30, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 55;
            this.label5.Text = "ROOM";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            this.Column1.Width = 38;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column2.HeaderText = "id";
            this.Column2.Name = "Column2";
            this.Column2.Visible = false;
            this.Column2.Width = 43;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column3.HeaderText = "SUBJECT CODE";
            this.Column3.Name = "Column3";
            this.Column3.Width = 109;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column4.HeaderText = "DESCRIPTIVE TITLE";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column5.HeaderText = "TIME";
            this.Column5.Name = "Column5";
            this.Column5.Width = 59;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column6.HeaderText = "DAY";
            this.Column6.Name = "Column6";
            this.Column6.Width = 52;
            // 
            // Column12
            // 
            this.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.Column12.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column12.HeaderText = "ROOM";
            this.Column12.Name = "Column12";
            this.Column12.Width = 68;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.Column7.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column7.HeaderText = "GRADE";
            this.Column7.Name = "Column7";
            this.Column7.Width = 68;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            this.Column8.DefaultCellStyle = dataGridViewCellStyle9;
            this.Column8.HeaderText = "SECTION";
            this.Column8.Name = "Column8";
            this.Column8.Width = 78;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.Column9.DefaultCellStyle = dataGridViewCellStyle10;
            this.Column9.HeaderText = "TEACHER";
            this.Column9.Name = "Column9";
            this.Column9.Width = 79;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column10.HeaderText = "";
            this.Column10.Image = ((System.Drawing.Image)(resources.GetObject("Column10.Image")));
            this.Column10.Name = "Column10";
            this.Column10.Width = 5;
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column11.HeaderText = "";
            this.Column11.Image = ((System.Drawing.Image)(resources.GetObject("Column11.Image")));
            this.Column11.Name = "Column11";
            this.Column11.Width = 5;
            // 
            // frmSchedulecs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 580);
            this.ControlBox = false;
            this.Controls.Add(this.cboRoom);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtYearTerm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cboSubjectTeacher);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtTeacherID);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.maskTo);
            this.Controls.Add(this.maskFrom);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.chkS);
            this.Controls.Add(this.chkT);
            this.Controls.Add(this.chkW);
            this.Controls.Add(this.chkTH);
            this.Controls.Add(this.chkF);
            this.Controls.Add(this.chkM);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtUnits);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtDescriptiveTitle);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cboSubjectCode);
            this.Controls.Add(this.cboAdviserName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtAdviserID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cboSection);
            this.Controls.Add(this.cboGradeLevel);
            this.Controls.Add(this.cboStrand);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAcademicYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmSchedulecs";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSchedulecs_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAcademicYear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboStrand;
        private System.Windows.Forms.ComboBox cboGradeLevel;
        private System.Windows.Forms.ComboBox cboSection;
        private System.Windows.Forms.TextBox txtAdviserID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cboSubjectCode;
        private System.Windows.Forms.ComboBox cboAdviserName;
        private System.Windows.Forms.TextBox txtDescriptiveTitle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtUnits;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chkM;
        private System.Windows.Forms.CheckBox chkF;
        private System.Windows.Forms.CheckBox chkTH;
        private System.Windows.Forms.CheckBox chkW;
        private System.Windows.Forms.CheckBox chkT;
        private System.Windows.Forms.CheckBox chkS;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox maskFrom;
        private System.Windows.Forms.MaskedTextBox maskTo;
        private System.Windows.Forms.TextBox txtTeacherID;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboSubjectTeacher;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtYearTerm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboRoom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewImageColumn Column10;
        private System.Windows.Forms.DataGridViewImageColumn Column11;
    }
}