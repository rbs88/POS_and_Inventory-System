﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmStudentList : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        public frmStudentList()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStudent WHERE status ='ACTIVE'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["id"].ToString(), dr["lrn"].ToString(), dr["fullname"].ToString(), DateTime.Parse(dr["birthdate"].ToString()).ToShortDateString(), dr["age"].ToString(), dr["birthplace"].ToString(), dr["contact"].ToString(), dr["gender"].ToString(), dr["marital"].ToString(), dr["citizenship"].ToString(), dr["address"].ToString());
            }
            dr.Close();
            cn.Close();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmStudent f = new frmStudent(this);
            f.btnSave.Enabled = true;
            f.btnUpdate.Enabled = false;
            f.ShowDialog();
        }

        private void frmStudentList_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName == "colEdit")
            {
                frmStudent f = new frmStudent(this);
                f.btnSave.Enabled = false;
                f.btnUpdate.Enabled = true;
                cn.Open();
                cm = new SqlCommand("SELECT * FROM tblStudent where id LIKE '"+ dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() +"'", cn);
                dr = cm.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    f.label32.Text= dr["id"].ToString();
                    f.txtLRN.Text = dr["lrn"].ToString();
                    f.txtLName.Text = dr["lname"].ToString();
                    f.txtFName.Text = dr["fname"].ToString();
                    f.txtMName.Text = dr["mname"].ToString();
                    f.cboStudentType.Text = dr["student_type"].ToString();
                    f.cboGender.Text = dr["gender"].ToString();
                    f.cboMaritalStatus.Text = dr["marital"].ToString();
                    f.chkALSPasser.Checked = bool.Parse(dr["als"].ToString());
                    f.chkHSC.Checked = bool.Parse(dr["hs_completer"].ToString());
                    f.chkJHSC.Checked = bool.Parse(dr["jhs_completer"].ToString());
                    f.chkPEPTPasser.Checked = bool.Parse(dr["pept"].ToString());
                    f.txtAddress.Text = dr["address"].ToString();
                    f.txtAge.Text = dr["age"].ToString();
                    f.txtALSRating.Text = dr["als_rating"].ToString();
                    f.txtCitizenship.Text = dr["citizenship"].ToString();
                    f.txtContactNumber.Text = dr["contact"].ToString();
                    f.txtDateOfExamination.Text = dr["assessment"].ToString();
                    f.txtFather.Text = dr["father"].ToString();
                    f.txtFatherOccupation.Text = dr["foccupation"].ToString();
                    f.txtGenAveHSC.Text = dr["hs_completer_GenAve"].ToString();
                    f.txtGenAveJHSC.Text = dr["jhs_completer_GenAve"].ToString();
                    f.txtHSCDateOfGraduation.Text = dr["graduation_completion"].ToString();
                    f.txtJHSCNameOfSchool.Text = dr["name_of_school"].ToString();
                    f.txtJHSCSchoolAddress.Text = dr["school_address"].ToString();
                    f.txtMother.Text = dr["mother"].ToString();
                    f.txtMotherOccupation.Text = dr["moccupation"].ToString();
                    f.txtNameAndAddressOfCommunityLCenter.Text = dr["community"].ToString();
                    f.txtOthersSpecipy.Text = dr["others"].ToString();
                    f.txtParentAddress.Text = dr["paddress"].ToString();
                    f.txtParentContact.Text = dr["pcontact"].ToString();
                    f.txtPEPTRating.Text = dr["pept_rating"].ToString();
                    f.txtPlaceOfBirth.Text = dr["birthplace"].ToString();
                    f.txtReligion.Text = dr["religion"].ToString();
                    f.dDateOfBirth.Value = DateTime.Parse(dr["birthdate"].ToString());
                    f.Show();
                }
                cn.Close();
            }
            else if (colName =="colDelete")
            {
                //try
                //{
                //    if (MessageBox.Show("DELETE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                //    {
                //        cn.Open();
                //        cm = new SqlCommand("DELETE FROM tblStudent WHERE id = '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                //        cm.ExecuteNonQuery();
                //        cn.Close();
                //        MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY DELETED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //        LoadRecords();
                //    }
                //}
                //catch (Exception ex)
                //{
                //    cn.Close();
                //    MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}

                try
                {
                    if (MessageBox.Show("MOVE TO ARCHIVE? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("UPDATE tblStudent SET status ='INACTIVE' WHERE lrn LIKE '" + dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString() + "'", cn);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("RECORD HAS BEEN SUCCESSFULL MOVED TO ARCHIVE", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadRecords();
                    }
                }
                catch (Exception ex)
                {
                    cn.Close();
                    MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
