﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmStudent : Form
    {
        SqlConnection cn;
        SqlCommand cm;
       // SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";

        frmStudentList f;
        public frmStudent(frmStudentList f)
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
            this.f = f;
        }

        private void frmStudent_Load(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dDateOfBirth_ValueChanged(object sender, EventArgs e)
        {
          //  txtAge.Text = Years(dDateOfBirth.Value.Date, DateTime.Now.Date).ToString();
        }

        int Years(DateTime start, DateTime end)
        {
            return (end.Year - start.Year -1) +
                (((end.Month > start.Month)) || ((end.Month == start.Month) && (end.Day >= start.Day))? 1: 0 );
        }

        private void cboGender_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cboMaritalStatus_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           
          
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void dDateOfBirth_ValueChanged_1(object sender, EventArgs e)
        {
            txtAge.Text = Years(dDateOfBirth.Value.Date, DateTime.Now.Date).ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void Clear() 
        {
            txtLRN.Clear();
            cboStudentType.ResetText();
            txtLName.Clear();
            txtFName.Clear();
            txtMName.Clear();
            txtAge.Clear();
            txtPlaceOfBirth.Clear();
            txtContactNumber.Clear();
            cboGender.ResetText();
            cboMaritalStatus.ResetText();
            txtCitizenship.Clear();
            txtReligion.Clear();
            txtAddress.Clear();
            txtFather.Clear();
            txtMother.Clear();
            txtFatherOccupation.Clear();
            txtMotherOccupation.Clear();
            txtParentAddress.Clear();
            txtParentContact.Clear();
            chkHSC.Checked = false;
            txtGenAveHSC.Clear();
            txtHSCDateOfGraduation.Clear();
            chkJHSC.Checked = false;
            txtGenAveJHSC.Clear();
            txtJHSCNameOfSchool.Clear();
            txtJHSCSchoolAddress.Clear();
            chkPEPTPasser.Checked = false;
            txtPEPTRating.Clear();
            chkALSPasser.Checked = false;
            txtALSRating.Clear();
            txtOthersSpecipy.Clear();
            txtDateOfExamination.Clear();
            txtNameAndAddressOfCommunityLCenter.Clear();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("SAVE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblStudent(lrn,student_type,lname,fname,mname,birthdate,age,birthplace,contact,gender,marital,citizenship,religion,address,father,mother,foccupation,moccupation,paddress,pcontact,hs_completer,hs_completer_GenAve,graduation_completion,jhs_completer,jhs_completer_GenAve,name_of_school,school_address,pept,pept_rating,als,als_rating,others,assessment,community)VALUES(@lrn,@student_type,@lname,@fname,@mname,@birthdate,@age,@birthplace,@contact,@gender,@marital,@citizenship,@religion,@address,@father,@mother,@foccupation,@moccupation,@paddress,@pcontact,@hs_completer,@hs_completer_GenAve,@graduation_completion,@jhs_completer,@jhs_completer_GenAve,@name_of_school,@school_address,@pept,@pept_rating,@als,@als_rating,@others,@assessment,@community)", cn);
                    cm.Parameters.AddWithValue("@lrn", txtLRN.Text);
                    cm.Parameters.AddWithValue("@student_type", cboStudentType.Text);
                    cm.Parameters.AddWithValue("@lname", txtLName.Text);
                    cm.Parameters.AddWithValue("@fname", txtFName.Text); 
                    cm.Parameters.AddWithValue("@mname", txtMName.Text);
                    cm.Parameters.AddWithValue("@birthdate", dDateOfBirth.Text);
                    cm.Parameters.AddWithValue("@age", txtAge.Text);
                    cm.Parameters.AddWithValue("@birthplace", txtPlaceOfBirth.Text);
                    cm.Parameters.AddWithValue("@contact", txtContactNumber.Text);
                    cm.Parameters.AddWithValue("@gender", cboGender.Text);
                    cm.Parameters.AddWithValue("@marital", cboMaritalStatus.Text);
                    cm.Parameters.AddWithValue("@citizenship", txtCitizenship.Text);
                    cm.Parameters.AddWithValue("@religion", txtReligion.Text);
                    cm.Parameters.AddWithValue("@address", txtAddress.Text);
                    cm.Parameters.AddWithValue("@father", txtFather.Text);
                    cm.Parameters.AddWithValue("@mother", txtMother.Text);
                    cm.Parameters.AddWithValue("@foccupation", txtFatherOccupation.Text);
                    cm.Parameters.AddWithValue("@moccupation", txtMotherOccupation.Text);
                    cm.Parameters.AddWithValue("@paddress", txtParentAddress.Text);
                    cm.Parameters.AddWithValue("@pcontact", txtParentContact.Text);
                    cm.Parameters.AddWithValue("@hs_completer", chkHSC.Checked.ToString());
                    cm.Parameters.AddWithValue("@hs_completer_GenAve", txtGenAveHSC.Text);
                    cm.Parameters.AddWithValue("@graduation_completion", txtHSCDateOfGraduation.Text);
                    cm.Parameters.AddWithValue("@jhs_completer", chkJHSC.Checked.ToString());
                    cm.Parameters.AddWithValue("@jhs_completer_GenAve", txtGenAveJHSC.Text);
                    cm.Parameters.AddWithValue("@name_of_school", txtJHSCNameOfSchool.Text);
                    cm.Parameters.AddWithValue("@school_address", txtJHSCSchoolAddress.Text);
                    cm.Parameters.AddWithValue("@pept", chkPEPTPasser.Checked.ToString());
                    cm.Parameters.AddWithValue("@pept_rating", txtPEPTRating.Text);
                    cm.Parameters.AddWithValue("@als", chkALSPasser.Checked.ToString());
                    cm.Parameters.AddWithValue("@als_rating", txtALSRating.Text);
                    cm.Parameters.AddWithValue("@others", txtOthersSpecipy.Text);
                    cm.Parameters.AddWithValue("@assessment", txtDateOfExamination.Text);
                    cm.Parameters.AddWithValue("@community", txtNameAndAddressOfCommunityLCenter.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    f.LoadRecords();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("UPDATE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblStudent SET lrn=@lrn,student_type=@student_type,lname=@lname,fname=@fname,mname=@fname,birthdate=@birthdate,age=@age,birthplace=@birthplace,contact=@contact,gender=@gender,marital=@marital,citizenship=@citizenship,religion=@religion,address=@address,father=@father,mother=@mother,foccupation=@foccupation,moccupation=@moccupation,paddress=@paddress,pcontact=@pcontact,hs_completer=@hs_completer,hs_completer_GenAve=@hs_completer_GenAve,graduation_completion=@graduation_completion,jhs_completer=@jhs_completer,jhs_completer_GenAve=@jhs_completer_GenAve,name_of_school=@name_of_school,school_address=@school_address,pept=@pept,pept_rating=@pept_rating,als=@als,als_rating=@als_rating,others=@others,assessment=@assessment,community=@community WHERE id=@id", cn);

                    cm.Parameters.AddWithValue("@id", label32.Text);
                    cm.Parameters.AddWithValue("@lrn", txtLRN.Text);
                    cm.Parameters.AddWithValue("@student_type", cboStudentType.Text);
                    cm.Parameters.AddWithValue("@lname", txtLName.Text);
                    cm.Parameters.AddWithValue("@fname", txtFName.Text);
                    cm.Parameters.AddWithValue("@mname", txtMName.Text);
                    cm.Parameters.AddWithValue("@birthdate", dDateOfBirth.Text);
                    cm.Parameters.AddWithValue("@age", txtAge.Text);
                    cm.Parameters.AddWithValue("@birthplace", txtPlaceOfBirth.Text);
                    cm.Parameters.AddWithValue("@contact", txtContactNumber.Text);
                    cm.Parameters.AddWithValue("@gender", cboGender.Text);
                    cm.Parameters.AddWithValue("@marital", cboMaritalStatus.Text);
                    cm.Parameters.AddWithValue("@citizenship", txtCitizenship.Text);
                    cm.Parameters.AddWithValue("@religion", txtReligion.Text);
                    cm.Parameters.AddWithValue("@address", txtAddress.Text);
                    cm.Parameters.AddWithValue("@father", txtFather.Text);
                    cm.Parameters.AddWithValue("@mother", txtMother.Text);
                    cm.Parameters.AddWithValue("@foccupation", txtFatherOccupation.Text);
                    cm.Parameters.AddWithValue("@moccupation", txtMotherOccupation.Text);
                    cm.Parameters.AddWithValue("@paddress", txtParentAddress.Text);
                    cm.Parameters.AddWithValue("@pcontact", txtParentContact.Text);
                    cm.Parameters.AddWithValue("@hs_completer", chkHSC.Checked.ToString());
                    cm.Parameters.AddWithValue("@hs_completer_GenAve", txtGenAveHSC.Text);
                    cm.Parameters.AddWithValue("@graduation_completion", txtHSCDateOfGraduation.Text);
                    cm.Parameters.AddWithValue("@jhs_completer", chkJHSC.Checked.ToString());
                    cm.Parameters.AddWithValue("@jhs_completer_GenAve", txtGenAveJHSC.Text);
                    cm.Parameters.AddWithValue("@name_of_school", txtJHSCNameOfSchool.Text);
                    cm.Parameters.AddWithValue("@school_address", txtJHSCSchoolAddress.Text);
                    cm.Parameters.AddWithValue("@pept", chkPEPTPasser.Checked.ToString());
                    cm.Parameters.AddWithValue("@pept_rating", txtPEPTRating.Text);
                    cm.Parameters.AddWithValue("@als", chkALSPasser.Checked.ToString());
                    cm.Parameters.AddWithValue("@als_rating", txtALSRating.Text);
                    cm.Parameters.AddWithValue("@others", txtOthersSpecipy.Text);
                    cm.Parameters.AddWithValue("@assessment", txtDateOfExamination.Text);
                    cm.Parameters.AddWithValue("@community", txtNameAndAddressOfCommunityLCenter.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY UPDATED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    this.Dispose();
                    f.LoadRecords();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
