﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmTeacher : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        string _title = "School Management System";
        ClassDB db = new ClassDB();
        frmTeacherList f;
    
        public frmTeacher(frmTeacherList f)
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
            this.f = f;
        }

        private void Clear() 
        {
            txtTeacherID.Clear();
            txtLName.Clear();
            txtFName.Clear();
            txtMName.Clear();
            txtUnderGrad.Clear();
            txtGrad.Clear();
            txtSpecialization.Clear();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            txtTeacherID.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("INSERT RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblTeacher (teacherid, lname, fname, mname, undergraduate, grad, specialization) VALUES (@teacherid, @lname, @fname, @mname, @undergraduate, @grad, @specialization)", cn);
                    cm.Parameters.AddWithValue("@teacherid", txtTeacherID.Text);
                    cm.Parameters.AddWithValue("@lname", txtLName.Text);
                    cm.Parameters.AddWithValue("@fname", txtFName.Text);
                    cm.Parameters.AddWithValue("@mname", txtMName.Text);
                    cm.Parameters.AddWithValue("@undergraduate", txtUnderGrad.Text);
                    cm.Parameters.AddWithValue("@grad", txtGrad.Text);
                    cm.Parameters.AddWithValue("@specialization", txtSpecialization.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("NEW RECORD HAS BEEN SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    f.LoadRecords();
                }
               
            }
            catch (Exception ex)
            {

                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("UPDATE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblTeacher SET teacherid =@teacherid, lname=@lname, fname=@fname, mname=@mname, undergraduate=@undergraduate, grad=@grad, specialization=@specialization WHERE teacherid=@teacherid", cn);
                  
                    cm.Parameters.AddWithValue("@teacherid", txtTeacherID.Text);
                    cm.Parameters.AddWithValue("@lname", txtLName.Text);
                    cm.Parameters.AddWithValue("@fname", txtFName.Text);
                    cm.Parameters.AddWithValue("@mname", txtMName.Text);
                    cm.Parameters.AddWithValue("@undergraduate", txtUnderGrad.Text);
                    cm.Parameters.AddWithValue("@grad", txtGrad.Text);
                    cm.Parameters.AddWithValue("@specialization", txtSpecialization.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("NEW RECORD HAS BEEN SUCCESSFULLY UPDATED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    f.LoadRecords();
                }

            }
            catch (Exception ex)
            {

                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
