﻿namespace UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.eNROLLMENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEMENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuManageStudent = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTeacher = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSchedule = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEGRADEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSubject = new System.Windows.Forms.ToolStripMenuItem();
            this.rECORDSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTUDENTRECORDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eNROLLMENTHISTORYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLASSLISTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuArchive = new System.Windows.Forms.ToolStripMenuItem();
            this.mAINTENANCEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAcademicYear = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrand = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSection = new System.Windows.Forms.ToolStripMenuItem();
            this.rEQUIREMENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRoom = new System.Windows.Forms.ToolStripMenuItem();
            this.sETTINGSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sCHOOLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aCCOUNTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPRESTOREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1357, 39);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(155, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "SCHOOL MANAGEMENT SYSTEM | RONEL SASON";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(850, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(507, 39);
            this.panel2.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSlateGray;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eNROLLMENTToolStripMenuItem,
            this.mANAGEMENTToolStripMenuItem,
            this.rECORDSToolStripMenuItem,
            this.mAINTENANCEToolStripMenuItem,
            this.sETTINGSToolStripMenuItem,
            this.lOGOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(507, 39);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // eNROLLMENTToolStripMenuItem
            // 
            this.eNROLLMENTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.eNROLLMENTToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.eNROLLMENTToolStripMenuItem.Name = "eNROLLMENTToolStripMenuItem";
            this.eNROLLMENTToolStripMenuItem.Size = new System.Drawing.Size(94, 35);
            this.eNROLLMENTToolStripMenuItem.Text = "ENROLLMENT";
            // 
            // mANAGEMENTToolStripMenuItem
            // 
            this.mANAGEMENTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mANAGEMENTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuManageStudent,
            this.menuTeacher,
            this.menuSchedule,
            this.mANAGEGRADEToolStripMenuItem,
            this.menuSubject});
            this.mANAGEMENTToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.mANAGEMENTToolStripMenuItem.Name = "mANAGEMENTToolStripMenuItem";
            this.mANAGEMENTToolStripMenuItem.Size = new System.Drawing.Size(101, 35);
            this.mANAGEMENTToolStripMenuItem.Text = "MANAGEMENT";
            // 
            // menuManageStudent
            // 
            this.menuManageStudent.BackColor = System.Drawing.Color.Black;
            this.menuManageStudent.ForeColor = System.Drawing.Color.White;
            this.menuManageStudent.Name = "menuManageStudent";
            this.menuManageStudent.Size = new System.Drawing.Size(184, 22);
            this.menuManageStudent.Text = "MANAGE STUDENT";
            this.menuManageStudent.Click += new System.EventHandler(this.menuManageStudent_Click);
            // 
            // menuTeacher
            // 
            this.menuTeacher.BackColor = System.Drawing.Color.Black;
            this.menuTeacher.ForeColor = System.Drawing.Color.White;
            this.menuTeacher.Name = "menuTeacher";
            this.menuTeacher.Size = new System.Drawing.Size(184, 22);
            this.menuTeacher.Text = "MANAGE TEACHER";
            this.menuTeacher.Click += new System.EventHandler(this.menuTeacher_Click);
            // 
            // menuSchedule
            // 
            this.menuSchedule.BackColor = System.Drawing.Color.Black;
            this.menuSchedule.ForeColor = System.Drawing.Color.White;
            this.menuSchedule.Name = "menuSchedule";
            this.menuSchedule.Size = new System.Drawing.Size(184, 22);
            this.menuSchedule.Text = "MANAGE SCHEDULE";
            this.menuSchedule.Click += new System.EventHandler(this.menuSchedule_Click);
            // 
            // mANAGEGRADEToolStripMenuItem
            // 
            this.mANAGEGRADEToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.mANAGEGRADEToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.mANAGEGRADEToolStripMenuItem.Name = "mANAGEGRADEToolStripMenuItem";
            this.mANAGEGRADEToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.mANAGEGRADEToolStripMenuItem.Text = "MANAGE GRADE";
            // 
            // menuSubject
            // 
            this.menuSubject.BackColor = System.Drawing.Color.Black;
            this.menuSubject.ForeColor = System.Drawing.Color.White;
            this.menuSubject.Name = "menuSubject";
            this.menuSubject.Size = new System.Drawing.Size(184, 22);
            this.menuSubject.Text = "MANAGE SUBJECT";
            this.menuSubject.Click += new System.EventHandler(this.menuSubject_Click);
            // 
            // rECORDSToolStripMenuItem
            // 
            this.rECORDSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.rECORDSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTUDENTRECORDToolStripMenuItem,
            this.eNROLLMENTHISTORYToolStripMenuItem,
            this.cLASSLISTToolStripMenuItem,
            this.menuArchive});
            this.rECORDSToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.rECORDSToolStripMenuItem.Name = "rECORDSToolStripMenuItem";
            this.rECORDSToolStripMenuItem.Size = new System.Drawing.Size(70, 35);
            this.rECORDSToolStripMenuItem.Text = "RECORDS";
            // 
            // sTUDENTRECORDToolStripMenuItem
            // 
            this.sTUDENTRECORDToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.sTUDENTRECORDToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.sTUDENTRECORDToolStripMenuItem.Name = "sTUDENTRECORDToolStripMenuItem";
            this.sTUDENTRECORDToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.sTUDENTRECORDToolStripMenuItem.Text = "STUDENT RECORD";
            // 
            // eNROLLMENTHISTORYToolStripMenuItem
            // 
            this.eNROLLMENTHISTORYToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.eNROLLMENTHISTORYToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.eNROLLMENTHISTORYToolStripMenuItem.Name = "eNROLLMENTHISTORYToolStripMenuItem";
            this.eNROLLMENTHISTORYToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.eNROLLMENTHISTORYToolStripMenuItem.Text = "ENROLLMENT HISTORY";
            // 
            // cLASSLISTToolStripMenuItem
            // 
            this.cLASSLISTToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.cLASSLISTToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.cLASSLISTToolStripMenuItem.Name = "cLASSLISTToolStripMenuItem";
            this.cLASSLISTToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.cLASSLISTToolStripMenuItem.Text = "CLASSLIST";
            // 
            // menuArchive
            // 
            this.menuArchive.BackColor = System.Drawing.Color.Black;
            this.menuArchive.ForeColor = System.Drawing.Color.White;
            this.menuArchive.Name = "menuArchive";
            this.menuArchive.Size = new System.Drawing.Size(198, 22);
            this.menuArchive.Text = "ARCHIVE";
            this.menuArchive.Click += new System.EventHandler(this.menuArchive_Click);
            // 
            // mAINTENANCEToolStripMenuItem
            // 
            this.mAINTENANCEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mAINTENANCEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAcademicYear,
            this.menuStrand,
            this.menuSection,
            this.rEQUIREMENTToolStripMenuItem,
            this.menuRoom});
            this.mAINTENANCEToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.mAINTENANCEToolStripMenuItem.Name = "mAINTENANCEToolStripMenuItem";
            this.mAINTENANCEToolStripMenuItem.Size = new System.Drawing.Size(102, 35);
            this.mAINTENANCEToolStripMenuItem.Text = "MAINTENANCE";
            // 
            // menuAcademicYear
            // 
            this.menuAcademicYear.BackColor = System.Drawing.Color.Black;
            this.menuAcademicYear.ForeColor = System.Drawing.Color.White;
            this.menuAcademicYear.Name = "menuAcademicYear";
            this.menuAcademicYear.Size = new System.Drawing.Size(165, 22);
            this.menuAcademicYear.Text = "ACADEMIC YEAR";
            this.menuAcademicYear.Click += new System.EventHandler(this.menuAcademicYear_Click);
            // 
            // menuStrand
            // 
            this.menuStrand.BackColor = System.Drawing.Color.Black;
            this.menuStrand.ForeColor = System.Drawing.Color.White;
            this.menuStrand.Name = "menuStrand";
            this.menuStrand.Size = new System.Drawing.Size(165, 22);
            this.menuStrand.Text = "STRAND";
            this.menuStrand.Click += new System.EventHandler(this.menuStrand_Click);
            // 
            // menuSection
            // 
            this.menuSection.BackColor = System.Drawing.Color.Black;
            this.menuSection.ForeColor = System.Drawing.Color.White;
            this.menuSection.Name = "menuSection";
            this.menuSection.Size = new System.Drawing.Size(165, 22);
            this.menuSection.Text = "SECTION";
            this.menuSection.Click += new System.EventHandler(this.menuSection_Click);
            // 
            // rEQUIREMENTToolStripMenuItem
            // 
            this.rEQUIREMENTToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.rEQUIREMENTToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.rEQUIREMENTToolStripMenuItem.Name = "rEQUIREMENTToolStripMenuItem";
            this.rEQUIREMENTToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.rEQUIREMENTToolStripMenuItem.Text = "REQUIREMENT";
            // 
            // menuRoom
            // 
            this.menuRoom.BackColor = System.Drawing.Color.Black;
            this.menuRoom.ForeColor = System.Drawing.Color.White;
            this.menuRoom.Name = "menuRoom";
            this.menuRoom.Size = new System.Drawing.Size(165, 22);
            this.menuRoom.Text = "ROOM";
            this.menuRoom.Click += new System.EventHandler(this.menuRoom_Click);
            // 
            // sETTINGSToolStripMenuItem
            // 
            this.sETTINGSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sETTINGSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sCHOOLToolStripMenuItem,
            this.aCCOUNTToolStripMenuItem,
            this.bACKUPRESTOREToolStripMenuItem});
            this.sETTINGSToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.sETTINGSToolStripMenuItem.Name = "sETTINGSToolStripMenuItem";
            this.sETTINGSToolStripMenuItem.Size = new System.Drawing.Size(69, 35);
            this.sETTINGSToolStripMenuItem.Text = "SETTINGS";
            // 
            // sCHOOLToolStripMenuItem
            // 
            this.sCHOOLToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.sCHOOLToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.sCHOOLToolStripMenuItem.Name = "sCHOOLToolStripMenuItem";
            this.sCHOOLToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.sCHOOLToolStripMenuItem.Text = "SCHOOL";
            // 
            // aCCOUNTToolStripMenuItem
            // 
            this.aCCOUNTToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.aCCOUNTToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.aCCOUNTToolStripMenuItem.Name = "aCCOUNTToolStripMenuItem";
            this.aCCOUNTToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.aCCOUNTToolStripMenuItem.Text = "ACCOUNT";
            // 
            // bACKUPRESTOREToolStripMenuItem
            // 
            this.bACKUPRESTOREToolStripMenuItem.BackColor = System.Drawing.Color.Black;
            this.bACKUPRESTOREToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.bACKUPRESTOREToolStripMenuItem.Name = "bACKUPRESTOREToolStripMenuItem";
            this.bACKUPRESTOREToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.bACKUPRESTOREToolStripMenuItem.Text = "BACKUP/RESTORE";
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(65, 35);
            this.lOGOUTToolStripMenuItem.Text = "LOGOUT";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dateTimePicker2);
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(0, 39);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1357, 670);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(226, 179);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(222, 23);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(493, 179);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(222, 23);
            this.dateTimePicker2.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1357, 709);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem eNROLLMENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEMENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuManageStudent;
        private System.Windows.Forms.ToolStripMenuItem menuTeacher;
        private System.Windows.Forms.ToolStripMenuItem menuSchedule;
        private System.Windows.Forms.ToolStripMenuItem mANAGEGRADEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuSubject;
        private System.Windows.Forms.ToolStripMenuItem rECORDSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTRECORDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eNROLLMENTHISTORYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLASSLISTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuArchive;
        private System.Windows.Forms.ToolStripMenuItem mAINTENANCEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuAcademicYear;
        private System.Windows.Forms.ToolStripMenuItem menuStrand;
        private System.Windows.Forms.ToolStripMenuItem menuSection;
        private System.Windows.Forms.ToolStripMenuItem rEQUIREMENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sETTINGSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sCHOOLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aCCOUNTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bACKUPRESTOREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolStripMenuItem menuRoom;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}

