﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace UI
{
    public partial class frmAcademicYear : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";    
        public frmAcademicYear()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());         
        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblAY", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["aycode"].ToString(), dr["year1"].ToString()+"-"+ dr["year2"].ToString(), dr["term"].ToString(), dr["status"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();       
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAY f = new frmAY(this);
            f.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName =="colOpen")
            {
                if (MessageBox.Show("OPEN THIS ACADEMIC YEAR/TERM? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblAY SET status = 'CLOSE'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();

                    cn.Open();
                    cm = new SqlCommand("UPDATE tblAY SET status = 'OPEN' WHERE aycode ='"+ dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() +"'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();

                    MessageBox.Show("ACADEMIC YEAR HAS BEEN SUCCESSFULLY OPENED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                }
            }
            else if (colName == "colClose")
            {
                if (MessageBox.Show("CLOSE THIS ACADEMIC YEAR/TERM? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {  
                    
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblAY SET status = 'CLOSE' WHERE aycode ='" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();

                    MessageBox.Show("ACADEMIC YEAR HAS BEEN SUCCESSFULLY CLOSED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
