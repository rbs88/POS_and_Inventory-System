﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmStrand : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        frmStrandList f;
        public frmStrand(frmStrandList f)
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
            this.f = f;
        }

        private void frmStrand_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtStrand.Clear();
            txtDescription.Clear();
            txtStrand.Focus();
        }

        private void Clear() 
        {
            txtStrand.Clear();
            txtDescription.Clear();
            txtStrand.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtStrand.Text == string.Empty || txtDescription.Text == string.Empty)
                {
                    MessageBox.Show("REQUIRED EMPTY FIELDS", _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("ADD NEW STRAND? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                 
                    //ADD NEW STRAND
                    cn.Open();
                    cm = new SqlCommand("SP_STRAND_INSERT", cn);
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@strand", txtStrand.Text);
                    cm.Parameters.AddWithValue("@description", txtDescription.Text);                
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("NEW STRAND HAS SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    f.LoadRecords();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title,MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtStrand.Text == string.Empty || txtDescription.Text == string.Empty)
                {
                    MessageBox.Show("REQUIRED EMPTY FIELDS", _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("UPDATE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    //ADD NEW STRAND
                    cn.Open();
                    cm = new SqlCommand("SP_STRAND_UPDATE", cn);
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@strand", txtStrand.Text);
                    cm.Parameters.AddWithValue("@description", txtDescription.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("STRAND HAS SUCCESSFULLY UPDATED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    f.LoadRecords();
                    this.Dispose();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
