﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmSection : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        frmSectionList f;
        string _title = "School Management System";
        public frmSection(frmSectionList f)
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
            this.f = f;
        }

        public void GetStrand() 
        {
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStrand", cn);
            dr = cm.ExecuteReader();
            cboStrand.Items.Clear();
            cboStrand.Items.Add("N/A");
            while (dr.Read())
            {
                cboStrand.Items.Add(dr["strand"].ToString());
            }
            dr.Close();
            cn.Close();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void cboGrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cboStrand_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Clear() 
        {
            cboGrade.ResetText();
            cboStrand.ResetText();
            txtSection.Clear();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            cboGrade.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboGrade.Text == string.Empty || cboStrand.Text == string.Empty || txtSection.Text == string.Empty)
                {
                    MessageBox.Show("REQUIRED EMPTY FIELDS", _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("ADD NEW STRAND? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    //ADD NEW STRAND
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblSection (grade,strand,section)VALUES(@grade,@strand,@section)", cn);                
                    cm.Parameters.AddWithValue("@grade", cboGrade.Text);
                    cm.Parameters.AddWithValue("@strand", cboStrand.Text);
                    cm.Parameters.AddWithValue("@section", txtSection.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    f.LoadRecords();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void frmSection_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboGrade.Text == string.Empty || cboStrand.Text == string.Empty || txtSection.Text == string.Empty)
                {
                    MessageBox.Show("REQUIRED EMPTY FIELDS", _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("UPDATE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    //ADD NEW STRAND
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblSection SET grade = @grade, strand =@strand, section=@section WHERE id = @id", cn);
                 //   cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@grade", cboGrade.Text);
                    cm.Parameters.AddWithValue("@strand", cboStrand.Text);
                    cm.Parameters.AddWithValue("@section", txtSection.Text);
                    cm.Parameters.AddWithValue("@id", label6.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS SUCCESSFULLY UPDATED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    f.LoadRecords();
                    this.Dispose();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
