﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            menuStrip1.BackColor = Color.FromArgb(64, 64, 64);
            menuStrip1.ForeColor = Color.White;
            menuStrip1.Cursor = Cursors.Hand;
            dateTimePicker1.Value = dateTimePicker2.Value.AddYears(2);
        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void menuAcademicYear_Click(object sender, EventArgs e)
        {
            frmAcademicYear frm = new frmAcademicYear();
            frm.TopLevel = false;           
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();

        }

        private void menuStrand_Click(object sender, EventArgs e)
        {
            frmStrandList frm = new frmStrandList();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuSection_Click(object sender, EventArgs e)
        {
            frmSectionList frm = new frmSectionList();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuManageStudent_Click(object sender, EventArgs e)
        {
            frmStudentList frm = new frmStudentList();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuArchive_Click(object sender, EventArgs e)
        {
            frmArchive frm = new frmArchive();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuTeacher_Click(object sender, EventArgs e)
        {
            frmTeacherList frm = new frmTeacherList();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();         
        }

        private void menuSubject_Click(object sender, EventArgs e)
        {
            frmSubjectList frm = new frmSubjectList();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuRoom_Click(object sender, EventArgs e)
        {
            frmRoom frm = new frmRoom();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.BringToFront();
            frm.Show();
        }

        private void menuSchedule_Click(object sender, EventArgs e)
        {
            frmSchedulecs frm = new frmSchedulecs();
            frm.TopLevel = false;
            panel3.Controls.Add(frm);
            frm.LoadRecords();
            frm.LoadStrand();
            frm.LoadTeacher();
            frm.LoadRoom();
            frm.BringToFront();
            frm.Show();
        }
    }
}
