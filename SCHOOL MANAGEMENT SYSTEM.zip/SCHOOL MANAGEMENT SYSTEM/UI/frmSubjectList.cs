﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmSubjectList : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
   
        public frmSubjectList()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());         
        }

        public void LoadRecords() 
        {
            try
            {
                dataGridView1.Rows.Clear();
                int i = 0;
                cn.Open();
                cm = new SqlCommand("SELECT * FROM tblSubject", cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    i++;
                    dataGridView1.Rows.Add(i, dr["id"].ToString(), dr["gradelevel"].ToString(), dr["subjectcode"].ToString(), dr["title"].ToString(), dr["units"].ToString(), dr["type"].ToString());
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSubject f = new frmSubject(this);
            f.btnSave.Enabled = true;
            f.btnUpdate.Enabled = false;
            f.ShowDialog();
        }

        private void frmSubjectList_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName =="colEdit")
            {
                frmSubject f = new frmSubject(this);
                f.label8.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                f.cboGradeLevel.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                f.txtSubjectCode.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                f.txtDescrpitiveTitle.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                f.txtUnits.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                f.cboType.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                f.btnSave.Enabled = false;
                f.btnUpdate.Enabled = true;
                f.cboGradeLevel.Focus();
                f.ShowDialog();
            }
            else if (colName =="colDelete")
            {
                try
                {
                    if (MessageBox.Show("DELETE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("DELETE FROM tblSubject WHERE id = '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY DELETED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadRecords();
                    }
                }
                catch (Exception ex)
                {
                    cn.Close();
                    MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
