﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmSubject : Form
    {
        SqlConnection cn;
        SqlCommand cm;
      //  SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        frmSubjectList f;
        public frmSubject(frmSubjectList f)
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
            this.f = f;
        }

        private void cboGradeLevel_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cboType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Clear() 
        {
            cboGradeLevel.ResetText();
            txtSubjectCode.Clear();
            txtDescrpitiveTitle.Clear();
            txtUnits.Clear();
            cboType.ResetText();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            cboGradeLevel.Focus();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("INSERT RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblSubject(gradelevel, subjectcode, title, units, type) VALUES (@gradelevel, @subjectcode, @title, @units, @type)", cn);
                    cm.Parameters.AddWithValue("@gradelevel", cboGradeLevel.Text);
                    cm.Parameters.AddWithValue("@subjectcode", txtSubjectCode.Text);
                    cm.Parameters.AddWithValue("@title", txtDescrpitiveTitle.Text);
                    cm.Parameters.AddWithValue("@units", txtUnits.Text);
                    cm.Parameters.AddWithValue("@type", cboType.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    f.LoadRecords();
                    Clear();                                     
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("UPDATE RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblSubject SET gradelevel=@gradelevel, subjectcode=@subjectcode, title=@title, units=@units, type=@type WHERE id=@id", cn);

                    cm.Parameters.AddWithValue("@id", label8.Text);
                    cm.Parameters.AddWithValue("@gradelevel", cboGradeLevel.Text);
                    cm.Parameters.AddWithValue("@subjectcode", txtSubjectCode.Text);
                    cm.Parameters.AddWithValue("@title", txtDescrpitiveTitle.Text);
                    cm.Parameters.AddWithValue("@units", txtUnits.Text);
                    cm.Parameters.AddWithValue("@type", cboType.Text);                                 
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY UPDATED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    f.LoadRecords();
                    this.Dispose();
                   
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
