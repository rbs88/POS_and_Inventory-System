﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace UI
{
    class ClassDB
    {
        private string _ay;
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        public string GetConnection() 
        {
            string cn = "Data Source=DESKTOP-5DN3RJN;Initial Catalog=SchoolManagementSystem;Integrated Security=True";
           // string cn = "Data Source=192.168.1.1,1433;Initial Catalog=SchoolManagementSystem;User Id=sa;Password=1234";// This Connection string is for Client Machine
            return cn;
        }

        public static string GetTitle() 
        {
            string _title = "SCHOOL MANAGEMENT SYSTEM";
            return _title;
        }

        public string GetAY() 
        {
            cn = new SqlConnection();
            cn.ConnectionString = GetConnection();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblAY WHERE status LIKE 'OPEN'", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                _ay = dr["aycode"].ToString();
            }
            else
            {
                _ay = ""; 
            }
            dr.Close();
            cn.Close();

            return _ay;
        }

        public string GetAYTerm()
        {
            cn = new SqlConnection();
            cn.ConnectionString = GetConnection();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblAY WHERE status LIKE 'OPEN'", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                _ay = dr["year1"].ToString() + "-" + dr["year2"].ToString() + " " + dr["term"].ToString();
            }
            else
            {
                _ay = "";
            }
            dr.Close();
            cn.Close();

            return _ay;
        }

        public string GetPrimaryKey(string sql) 
        {
            string id = string.Empty;
            cn.Open();
            cm = new SqlCommand(sql, cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                id = dr[0].ToString();
            }
            dr.Close();
            cn.Close();
            return id;
        }
    }
}
