﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmStrandList : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        public frmStrandList()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStrand", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["strand"].ToString(), dr["description"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void frmStrandList_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmStrand f = new frmStrand(this);
            f.btnSave.Enabled = true;
            f.btnUpdate.Enabled = false;
            f.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName == "colEdit")
            {
                frmStrand f = new frmStrand(this);
                f.btnSave.Enabled = false;
                f.btnUpdate.Enabled = true;
                f.txtStrand.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                f.txtDescription.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                f.txtStrand.Enabled = false;
                f.ShowDialog();
            }
            else if (colName == "colDelete")
            {
                if (MessageBox.Show("YOU WANT TO DELETE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("DELETE FROM tblStrand WHERE strand = '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULL DELETED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                }
               
            }
        }
    }
}
