﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmRoom : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        public frmRoom()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void Clear() 
        {
            txtRoom.Clear();
            btnSave.Enabled = true;        
            txtRoom.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("INSERT RECORD? CLICK YES TO CONFIRM",_title, MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblRoom (room)VALUES(@room)", cn);
                    cm.Parameters.AddWithValue("@room", txtRoom.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("NEW ROOM HAS BEEN SUCCESSFULLY SAVED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblRoom", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["room"].ToString());               
            }
            dr.Close();
            cn.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
           
            if (colName == "colDelete")
            {
                if (MessageBox.Show("YOU WANT TO DELETE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("DELETE FROM tblRoom WHERE room = '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULL DELETED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                }

            }
        }
    }
}
