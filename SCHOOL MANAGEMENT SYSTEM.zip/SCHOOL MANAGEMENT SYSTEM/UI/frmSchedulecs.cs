﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmSchedulecs : Form
    {

        ClassDB db = new ClassDB();

        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        public frmSchedulecs()
        {
            InitializeComponent();
            txtAcademicYear.Text = db.GetAY();
            txtYearTerm.Text = db.GetAYTerm();
            cn = new SqlConnection(db.GetConnection());
        }

        public void LoadStrand() 
        {
            cboStrand.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStrand", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboStrand.Items.Add(dr["strand"].ToString());
            }
            dr.Close();
            cn.Close();

        }
        private void frmSchedulecs_Load(object sender, EventArgs e)
        {

        }

        public void LoadSection() 
        {
            cboSection.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblSection WHERE strand = @strand and grade =@grade", cn);
            cm.Parameters.AddWithValue("@strand", cboStrand.Text);
            cm.Parameters.AddWithValue("@grade", cboGradeLevel.Text);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboSection.Items.Add(dr["section"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void cboStrand_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cboStrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboSection.Text = "";
            LoadSection();
        }

        private void cboGradeLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboSection.Text = "";
            LoadSection();
            LoadSubject();
        }
        public void LoadTeacher()
        {
            cboSubjectTeacher.Items.Clear();
            cboAdviserName.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblTeacher", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboSubjectTeacher.Items.Add(dr["fullname"].ToString());
                cboAdviserName.Items.Add(dr["fullname"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void cboAdviserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblTeacher WHERE fullname LIKE '"+ cboAdviserName.Text +"'", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                txtAdviserID.Text = dr["teacherid"].ToString();
            }
            else
            {
                txtAdviserID.Clear();
            }
            dr.Close();
            cn.Close();
        }

        private void cboSubjectTeacher_SelectedIndexChanged(object sender, EventArgs e)
        {

            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblTeacher WHERE fullname LIKE '" + cboSubjectTeacher.Text + "'", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                txtTeacherID.Text = dr["teacherid"].ToString();
            }
            else
            {
                txtTeacherID.Clear();
            }
            dr.Close();
            cn.Close();
        }

        public void LoadSubject() 
        {
            cboSubjectCode.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblSubject WHERE gradelevel LIKE '"+ cboGradeLevel.Text + "'", cn);
            dr = cm.ExecuteReader();         
            while (dr.Read())
            {
                cboSubjectCode.Items.Add(dr["subjectcode"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        public void LoadRoom()
        {
            cboRoom.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblRoom", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboRoom.Items.Add(dr["room"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void cboSubjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {

            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblSubject WHERE subjectcode LIKE '"+ cboSubjectCode.Text +"' ", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                txtDescriptiveTitle.Text = dr["title"].ToString();
                txtUnits.Text = dr["units"].ToString();
            }
            cn.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string secid = db.GetPrimaryKey("SELECT id FROM tblSection WHERE section LIKE '" + cboSection.Text + "'");
                string subid = db.GetPrimaryKey("SELECT id FROM tblSubject WHERE subjectcode LIKE '" + cboSubjectCode.Text + "'");
                if (MessageBox.Show("SAVED THIS SCHEDULE? CLICK YES TO CONFIRM", ClassDB.GetTitle(), MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblSchedule (aycode, sectionid, room, adviserid, subid, mon, tue, wed, thu, fri, sat, timefrom, timeto, teacherid)VALUES(@aycode, @sectionid, @room, @adviserid, @subid, @mon, @tue, @wed, @thu, @fri, @sat, @timefrom, @timeto, @teacherid)", cn);
                    cm.Parameters.AddWithValue("@aycode", txtAcademicYear.Text);
                    cm.Parameters.AddWithValue("@sectionid", int.Parse(secid));
                    cm.Parameters.AddWithValue("@room", cboRoom.Text);
                    cm.Parameters.AddWithValue("@adviserid", txtAdviserID.Text);
                    cm.Parameters.AddWithValue("@subid",  int.Parse(subid));
                    cm.Parameters.AddWithValue("@mon", chkM.Checked.ToString());
                    cm.Parameters.AddWithValue("@tue", chkT.Checked.ToString());
                    cm.Parameters.AddWithValue("@wed", chkW.Checked.ToString());
                    cm.Parameters.AddWithValue("@thu", chkTH.Checked.ToString());
                    cm.Parameters.AddWithValue("@fri", chkF.Checked.ToString());
                    cm.Parameters.AddWithValue("@sat", chkF.Checked.ToString());
                    cm.Parameters.AddWithValue("@timefrom", maskFrom.Text.ToString());
                    cm.Parameters.AddWithValue("@timeto", maskTo.Text.ToString());
                    cm.Parameters.AddWithValue("@teacherid", txtTeacherID.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULLY SAVED", ClassDB.GetTitle(), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    LoadRecords();
                }               
            }
            catch (Exception ex)
            {

                cn.Close();
                MessageBox.Show(ex.Message, ClassDB.GetTitle(), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            string day ="";
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM View_3", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                if (bool.Parse(dr["mon"].ToString()) == true) { day = "M"; }
                if (bool.Parse(dr["tue"].ToString()) == true) { day += "T"; }
                if (bool.Parse(dr["wed"].ToString()) == true) { day += "W"; }
                if (bool.Parse(dr["thu"].ToString()) == true) { day += "TH"; }
                if (bool.Parse(dr["fri"].ToString()) == true) { day += "F"; }
                if (bool.Parse(dr["sat"].ToString()) == true) { day += "S"; }
                dataGridView1.Rows.Add(i, dr["id"].ToString(), dr["subjectcode"].ToString(), dr["title"].ToString(), dr["timefrom"].ToString()+ "-" + dr["timeto"].ToString(), day, dr["room"].ToString(),dr["grade"].ToString(), dr["section"].ToString(), dr["fullname"].ToString());
            }
            dr.Close();
            cn.Close();
        }
    }
}
