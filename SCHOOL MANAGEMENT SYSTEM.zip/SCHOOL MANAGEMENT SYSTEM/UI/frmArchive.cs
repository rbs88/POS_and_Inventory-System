﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmArchive : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        public frmArchive()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string colName = dataGridView1.Columns[e.ColumnIndex].Name;
                if (colName == "colRestore")
                {
                    if (MessageBox.Show("RESTORE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();                   
                        cm = new SqlCommand("UPDATE tblStudent SET status ='ACTIVE' WHERE lrn LIKE '"+ dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString() +"'", cn);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("RECORD HAS BEEN SUCCESSFULL RESTORED", _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LoadRecords();
                    }
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, _title, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
           
        }

        private void frmArchive_Load(object sender, EventArgs e)
        {

        }

        public void LoadRecords() 
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStudent WHERE status ='INACTIVE'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["id"].ToString(), dr["lrn"].ToString(), dr["fullname"].ToString(), DateTime.Parse(dr["birthdate"].ToString()).ToShortDateString(), dr["age"].ToString(), dr["birthplace"].ToString(), dr["contact"].ToString(), dr["gender"].ToString(), dr["marital"].ToString(), dr["citizenship"].ToString(), dr["address"].ToString());
            }
            dr.Close();
            cn.Close();
        }
    }
}
