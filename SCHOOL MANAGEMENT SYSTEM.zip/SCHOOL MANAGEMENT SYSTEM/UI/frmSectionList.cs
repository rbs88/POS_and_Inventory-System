﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UI
{
    public partial class frmSectionList : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        ClassDB db = new ClassDB();
        string _title = "School Management System";
        public frmSectionList()
        {
            InitializeComponent();
            cn = new SqlConnection(db.GetConnection());
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSection f = new frmSection(this);
            f.GetStrand();
            f.btnSave.Enabled = true;
            f.btnUpdate.Enabled = false;
            f.cboGrade.Focus();
            f.ShowDialog();
        }

        private void frmSectionList_Load(object sender, EventArgs e)
        {

        }

        public void LoadRecords()
        {
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblSection", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["id"].ToString(), dr["grade"].ToString(), dr["strand"].ToString(), dr["section"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (colName == "colEdit")
            {
                frmSection f = new frmSection(this);
                f.btnSave.Enabled = false;
                f.btnUpdate.Enabled = true;
                f.label6.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                f.cboGrade.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                f.cboStrand.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                f.txtSection.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();              
                f.ShowDialog();
            }
            else if (colName == "colDelete")
            {
                if (MessageBox.Show("YOU WANT TO DELETE THIS RECORD? CLICK YES TO CONFIRM", _title, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("DELETE FROM tblSection WHERE id = '" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("RECORD HAS BEEN SUCCESSFULL DELETED", _title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRecords();
                }

            }
        }
        DataTable dt;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView DV = new DataView(dt);
            DV.RowFilter = string.Format("PRECINCT LIKE '%{0}%'", textBox1.Text);
            dataGridView1.DataSource = DV;
        }
    }
}
